package com.example.listkuliner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recKuliner;
    private ArrayList<Kuliner> listKuliner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recKuliner = findViewById(R.id.rec_kuliner);
        initData();

        recKuliner.setAdapter(new KulinerAdapter(listKuliner));
        recKuliner.setLayoutManager(new LinearLayoutManager(this ));

    }

    private void initData(){
        this.listKuliner = new ArrayList<>();
        listKuliner.add(new Kuliner ("Pecel Lele",
                "15.000",
                "Lele yang digoreng di tambah sambal dan lalapan",
                R.drawable.pecellele));

        listKuliner.add(new Kuliner ("Nasi Goreng Mercon",
                "14.500",
                "Nasi Goreng mercon yang pedas",
                R.drawable.nasigorengmercon));

        listKuliner.add(new Kuliner ("Ayam Geprek Keju",
                "20.000",
                "Ayam Geprek dengan topping keju",
                R.drawable.ayamgeprekkeju));

        listKuliner.add(new Kuliner ("Kari Ayam",
                "17.500",
                "Ayam yang di masak dengan santan yamg kental",
                R.drawable.kariayam));

        listKuliner.add(new Kuliner ("Tahu Bulat",
                "500",
                "Indonesian Rice Bowl",
                R.drawable.tahubulat));

        listKuliner.add(new Kuliner ("Salad Buah",
                "12.000",
                "Buah segar yang di potong dan diberi saus perpaduan antara susu kental manis, yoghurt, mayonise dan parutan keju di atasnya ",
                R.drawable.saladbuah));
    }
}